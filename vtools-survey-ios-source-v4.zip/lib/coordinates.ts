export type LonLat = { latitude: number; longitude: number };
export type UTMCoordinate = LonLat & { easting: number; northing: number; zone: number; hemisphere: "N" | "S" };

const A = 6378137;
const ECC_SQUARED = 0.00669438;
const K0 = 0.9996;

/** Convert WGS84 latitude/longitude to a practical UTM coordinate. */
export function wgs84ToUtm(point: LonLat): UTMCoordinate {
  const zone = Math.floor((point.longitude + 180) / 6) + 1;
  const latRad = (point.latitude * Math.PI) / 180;
  const lonRad = (point.longitude * Math.PI) / 180;
  const lonOrigin = ((zone - 1) * 6 - 180 + 3) * Math.PI / 180;
  const eccPrimeSquared = ECC_SQUARED / (1 - ECC_SQUARED);
  const n = A / Math.sqrt(1 - ECC_SQUARED * Math.sin(latRad) ** 2);
  const t = Math.tan(latRad) ** 2;
  const c = eccPrimeSquared * Math.cos(latRad) ** 2;
  const aa = Math.cos(latRad) * (lonRad - lonOrigin);
  const m = A * ((1 - ECC_SQUARED / 4 - 3 * ECC_SQUARED ** 2 / 64 - 5 * ECC_SQUARED ** 3 / 256) * latRad - (3 * ECC_SQUARED / 8 + 3 * ECC_SQUARED ** 2 / 32 + 45 * ECC_SQUARED ** 3 / 1024) * Math.sin(2 * latRad) + (15 * ECC_SQUARED ** 2 / 256 + 45 * ECC_SQUARED ** 3 / 1024) * Math.sin(4 * latRad) - (35 * ECC_SQUARED ** 3 / 3072) * Math.sin(6 * latRad));
  const easting = K0 * n * (aa + (1 - t + c) * aa ** 3 / 6 + (5 - 18 * t + t ** 2 + 72 * c - 58 * eccPrimeSquared) * aa ** 5 / 120) + 500000;
  let northing = K0 * (m + n * Math.tan(latRad) * (aa ** 2 / 2 + (5 - t + 9 * c + 4 * c ** 2) * aa ** 4 / 24 + (61 - 58 * t + t ** 2 + 600 * c - 330 * eccPrimeSquared) * aa ** 6 / 720));
  const hemisphere = point.latitude >= 0 ? "N" : "S";
  if (point.latitude < 0) northing += 10000000;
  return { ...point, easting, northing, zone, hemisphere };
}

export function formatCoordinate(point: LonLat, mode: "decimal" | "dms" = "decimal") {
  if (mode === "decimal") return `${point.latitude.toFixed(6)}, ${point.longitude.toFixed(6)}`;
  const dms = (value: number) => { const abs = Math.abs(value); const degrees = Math.floor(abs); const minutesFloat = (abs - degrees) * 60; const minutes = Math.floor(minutesFloat); const seconds = ((minutesFloat - minutes) * 60).toFixed(2); return `${degrees}°${minutes}'${seconds}\"`; };
  return `${dms(point.latitude)}${point.latitude >= 0 ? "N" : "S"}, ${dms(point.longitude)}${point.longitude >= 0 ? "E" : "W"}`;
}
