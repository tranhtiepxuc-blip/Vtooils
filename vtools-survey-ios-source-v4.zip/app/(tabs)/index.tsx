import { useEffect, useMemo, useState } from "react";
import { Alert, ImageBackground, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { wgs84ToUtm } from "@/lib/coordinates";
import { Magnetometer } from "expo-sensors";

const mapAsset = require("@/assets/images/android-reference/osm-standard.jpg");

type Panel = "import" | "coordinates" | "layers" | "tools" | "forms" | "sensors" | "offline" | "media" | null;

export default function HomeScreen() {
  const [panel, setPanel] = useState<Panel>(null);
  const [projectName, setProjectName] = useState("Khảo sát mới");
  const [objects, setObjects] = useState(4);
  const [coordinateSystem, setCoordinateSystem] = useState("WGS 84 · EPSG:4326");
  const [heading, setHeading] = useState<number | null>(null);
  useEffect(() => {
    AsyncStorage.getItem("vtools-coordinate-system").then((value) => { if (value) setCoordinateSystem(value); });
    if (Platform.OS === "web") return;
    let subscription: { remove: () => void } | undefined;
    Magnetometer.isAvailableAsync().then((available) => {
      if (!available) return;
      Magnetometer.setUpdateInterval(500);
      subscription = Magnetometer.addListener(({ x, y }) => {
        const angle = (Math.atan2(y, x) * 180) / Math.PI;
        setHeading(Math.round((angle + 360) % 360));
      });
    });
    return () => subscription?.remove();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem("vtools-coordinate-system", coordinateSystem).catch(() => undefined);
  }, [coordinateSystem]);

  const quickItems = useMemo(() => [
    { label: "Điểm", symbol: "+", onPress: () => router.push("/(tabs)/map" as never) },
    { label: "Đường", symbol: "／", onPress: () => router.push("/(tabs)/map" as never) },
    { label: "Vùng", symbol: "▱", onPress: () => router.push("/(tabs)/map" as never) },
    { label: "Tracklog", symbol: "⌁", onPress: () => router.push("/(tabs)/map" as never) },
  ], []);

  async function importMap() {
    const result = await DocumentPicker.getDocumentAsync({ type: ["application/json", "application/xml", "text/xml", "text/csv", "application/zip"], copyToCacheDirectory: true });
    if (result.canceled) return;
    const asset = result.assets[0];
    try {
      const preview = await FileSystem.readAsStringAsync(asset.uri, { length: 512 });
      await AsyncStorage.setItem("vtools-last-import", JSON.stringify({ name: asset.name, uri: asset.uri, coordinateSystem, preview }));
      setObjects((value) => value + 1);
      setPanel(null);
      Alert.alert("Đã nhập bản đồ", `${asset.name} đã được thêm vào dự án cục bộ.`);
    } catch {
      Alert.alert("Không thể nhập", "File không thể đọc trên iPhone. Hãy chọn GeoJSON, GPX, KML, CSV hoặc gói bản đồ hợp lệ.");
    }
  }

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} containerClassName="bg-white">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View><Text style={styles.eyebrow}>DỰ ÁN HIỆN TẠI</Text><Text style={styles.title}>{projectName}</Text></View>
          <View style={styles.localPill}><View style={styles.dot} /><Text style={styles.localText}>Cục bộ</Text></View>
        </View>
        <View style={styles.mapCard}>
          <ImageBackground source={mapAsset} resizeMode="cover" style={styles.mapImage} imageStyle={styles.mapImageRadius}>
            <View style={styles.objectBadge}><Text style={styles.objectBadgeText}>{objects} đối tượng</Text></View>
            <View style={styles.locationButton}><Text style={styles.target}>◎</Text></View>
          </ImageBackground>
        </View>
        <View style={styles.section}><Text style={styles.sectionTitle}>THU THẬP NHANH</Text><View style={styles.quickRow}>{quickItems.map((item) => <Pressable key={item.label} onPress={item.onPress} style={({ pressed }) => [styles.quickCard, pressed && styles.pressed]}><Text style={styles.quickSymbol}>{item.symbol}</Text><Text style={styles.quickLabel}>{item.label}</Text></Pressable>)}</View></View>
        <View style={styles.section}><Text style={styles.sectionTitle}>CÔNG CỤ KHẢO SÁT</Text><View style={styles.toolGrid}>
          <Tool title="Nhập bản đồ" subtitle="GeoJSON · GPX · KML" onPress={() => setPanel("import")} />
          <Tool title="Hệ tọa độ" subtitle="WGS84 · UTM · VN" onPress={() => setPanel("coordinates")} />
          <Tool title="Lớp bản đồ" subtitle="OSM · WMS · TMS" onPress={() => setPanel("layers")} />
          <Tool title="Đo đạc" subtitle="Khoảng cách · Diện tích" onPress={() => router.push("/(tabs)/map" as never)} />
          <Tool title="Dự án" subtitle="Đổi tên · Khôi phục" onPress={() => setPanel("tools")} />
          <Tool title="Xuất dữ liệu" subtitle="GeoJSON · CSV · GPX" onPress={() => router.push("/(tabs)/map" as never)} />
          <Tool title="Biểu mẫu" subtitle="Thuộc tính đối tượng" onPress={() => setPanel("forms")} />
          <Tool title="GNSS / La bàn" subtitle="Vệ tinh · phương vị" onPress={() => setPanel("sensors")} />
          <Tool title="Offline" subtitle="Bản đồ không mạng" onPress={() => setPanel("offline")} />
          <Tool title="Ảnh / EXIF" subtitle="Camera khảo sát" onPress={() => setPanel("media")} />
        </View></View>
        <View style={styles.statusCard}><View style={styles.statusDot} /><View style={{ flex: 1 }}><Text style={styles.statusTitle}>Khảo sát cục bộ</Text><Text style={styles.statusText}>Dữ liệu được lưu trên iPhone và có thể làm việc ngoại tuyến.</Text></View><Text style={styles.statusArrow}>›</Text></View>
      </ScrollView>
      <PanelModal panel={panel} close={() => setPanel(null)} projectName={projectName} setProjectName={setProjectName} objects={objects} setObjects={setObjects} importMap={importMap} coordinateSystem={coordinateSystem} setCoordinateSystem={setCoordinateSystem} heading={heading} />
    </ScreenContainer>
  );
}

function Tool({ title, subtitle, onPress }: { title: string; subtitle: string; onPress: () => void }) {
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.tool, pressed && styles.pressed]}><Text style={styles.toolTitle}>{title}</Text><Text style={styles.toolSubtitle}>{subtitle}</Text><Text style={styles.chevron}>›</Text></Pressable>;
}

function PanelModal({ panel, close, projectName, setProjectName, objects, setObjects, importMap, coordinateSystem, setCoordinateSystem, heading }: { panel: Panel; close: () => void; projectName: string; setProjectName: (v: string) => void; objects: number; setObjects: (v: number) => void; importMap: () => Promise<void>; coordinateSystem: string; setCoordinateSystem: (v: string) => void; heading: number | null }) {
  if (!panel) return null;
  const sampleUtm = wgs84ToUtm({ latitude: 21.0285, longitude: 105.8542 });
  const titles: Record<Exclude<Panel, null>, string> = { import: "Nhập bản đồ", coordinates: "Hệ tọa độ", layers: "Lớp bản đồ", tools: "Quản lý dự án", forms: "Biểu mẫu & thuộc tính", sensors: "GNSS & la bàn", offline: "Bản đồ ngoại tuyến", media: "Ảnh & EXIF" };
  const body = panel === "forms" ? <><PanelRow title="Thuộc tính điểm/đường/vùng" detail="Tên, mã, ghi chú và trường tùy chỉnh" /><PanelRow title="Biểu mẫu khảo sát" detail="Tạo bộ trường cho từng loại đối tượng" /><Text style={styles.note}>Các trường thuộc tính sẽ được lưu cùng GeoJSON và bảng CSV xuất ra.</Text></> : panel === "sensors" ? <><PanelRow title="GNSS" detail="Độ chính xác, số vệ tinh và cao độ" /><PanelRow title="La bàn" detail={heading === null ? "Đang chờ cảm biến iPhone" : `Phương vị hiện tại ${heading}°`} /><PanelRow title="Radar vệ tinh" detail="Hiển thị trạng thái thu tín hiệu" /></> : panel === "offline" ? <><PanelRow title="Tải vùng bản đồ" detail="Lưu vùng OSM để dùng khi mất mạng" /><PanelRow title="MBTiles" detail="Mở gói raster/vector ngoại tuyến" /><PanelRow title="Bộ nhớ dự án" detail="Theo dõi dung lượng và xóa cache" /></> : panel === "media" ? <><PanelRow title="Chụp ảnh khảo sát" detail="Gắn ảnh vào đối tượng hiện tại" /><PanelRow title="EXIF / GPS" detail="Đọc tọa độ, thời gian và hướng máy ảnh" /><PanelRow title="Thư viện ảnh" detail="Chọn ảnh có sẵn trên iPhone" /></> : panel === "import" ? <><Pressable onPress={importMap}><PanelRow title="Chọn file bản đồ" detail="GeoJSON, GPX, KML, CSV và gói dữ liệu" selected /></Pressable><PanelRow title="SHP / DXF / MBTiles" detail="Định dạng lớp vector/raster nâng cao" /><Text style={styles.note}>File được chọn qua bộ chọn tài liệu iOS và lưu thông tin vào dự án cục bộ.</Text></> : panel === "coordinates" ? <><Pressable onPress={() => setCoordinateSystem("WGS 84 · EPSG:4326")}><PanelRow title="WGS 84 · EPSG:4326" detail="Kinh độ / vĩ độ toàn cầu" selected={coordinateSystem.startsWith("WGS")} /></Pressable><Pressable onPress={() => setCoordinateSystem("UTM · tự động") }><PanelRow title="UTM" detail={`Zone ${sampleUtm.zone}${sampleUtm.hemisphere} · E ${Math.round(sampleUtm.easting)} · N ${Math.round(sampleUtm.northing)}`} selected={coordinateSystem.startsWith("UTM")} /></Pressable><Pressable onPress={() => setCoordinateSystem("VN-2000") }><PanelRow title="VN-2000" detail="Cấu hình múi chiếu và kinh tuyến trục" selected={coordinateSystem.startsWith("VN")} /></Pressable><PanelRow title="Định dạng hiển thị" detail={`${coordinateSystem} · Decimal degrees · DMS · mét`} /></> : panel === "layers" ? <><PanelRow title="OpenStreetMap" detail="Lớp nền mặc định" selected /><PanelRow title="Ảnh vệ tinh" detail="Lớp raster trực tuyến" /><PanelRow title="WMS / TMS" detail="Thêm URL dịch vụ bản đồ" /><PanelRow title="MBTiles ngoại tuyến" detail="Đọc gói bản đồ cục bộ" /></> : <><Text style={styles.fieldLabel}>TÊN DỰ ÁN</Text><Pressable style={styles.inputLike} onPress={() => setProjectName(projectName === "Khảo sát mới" ? "Khảo sát thực địa" : "Khảo sát mới")}><Text style={styles.inputText}>{projectName}</Text></Pressable><PanelRow title="Đối tượng hiện tại" detail={`${objects} đối tượng trong dự án`} /><PanelRow title="Lưu trữ" detail="Cục bộ trên iPhone · không cần tài khoản" /></>;
  return <Modal visible transparent animationType="slide" onRequestClose={close}><View style={styles.backdrop}><View style={styles.sheet}><View style={styles.sheetHeader}><Text style={styles.sheetTitle}>{titles[panel]}</Text><Pressable onPress={close}><Text style={styles.close}>Đóng</Text></Pressable></View><ScrollView>{body}</ScrollView><Pressable style={styles.done} onPress={() => { close(); }}><Text style={styles.doneText}>Xong</Text></Pressable></View></View></Modal>;
}

function PanelRow({ title, detail, selected }: { title: string; detail: string; selected?: boolean }) { return <View style={styles.panelRow}><View style={{ flex: 1 }}><Text style={styles.panelTitle}>{title}</Text><Text style={styles.panelDetail}>{detail}</Text></View><Text style={selected ? styles.selected : styles.radio}>{selected ? "✓" : "○"}</Text></View>; }

const styles = StyleSheet.create({ content: { paddingBottom: 28, backgroundColor: "#FFFFFF" }, header: { paddingHorizontal: 24, paddingTop: 22, paddingBottom: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "#F7F8F4" }, eyebrow: { color: "#68756D", fontSize: 11, fontWeight: "800", letterSpacing: 1.5 }, title: { color: "#17211D", fontSize: 27, fontWeight: "800", marginTop: 6 }, localPill: { flexDirection: "row", alignItems: "center", backgroundColor: "#E7F2E9", borderRadius: 20, paddingHorizontal: 14, paddingVertical: 9 }, dot: { width: 8, height: 8, borderRadius: 5, backgroundColor: "#3E8E5B", marginRight: 7 }, localText: { color: "#2F6D45", fontSize: 13, fontWeight: "800" }, mapCard: { height: 330, backgroundColor: "#DDE8DC" }, mapImage: { flex: 1 }, mapImageRadius: { opacity: 0.96 }, objectBadge: { position: "absolute", left: 22, top: 24, backgroundColor: "#FFFFFF", borderRadius: 22, paddingHorizontal: 18, paddingVertical: 11 }, objectBadgeText: { color: "#21463B", fontSize: 16, fontWeight: "800" }, locationButton: { position: "absolute", right: 20, bottom: 20, width: 66, height: 66, borderRadius: 35, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOpacity: 0.12, shadowRadius: 12, elevation: 4 }, target: { color: "#1677FF", fontSize: 38, lineHeight: 42 }, section: { paddingHorizontal: 22, paddingTop: 20 }, sectionTitle: { color: "#68756D", fontSize: 11, fontWeight: "800", letterSpacing: 1.5, marginBottom: 12 }, quickRow: { flexDirection: "row", justifyContent: "space-between" }, quickCard: { width: "23.5%", minHeight: 102, borderRadius: 20, backgroundColor: "#F1F6F0", alignItems: "center", justifyContent: "center" }, quickSymbol: { color: "#1677FF", fontSize: 36, lineHeight: 40, marginBottom: 7 }, quickLabel: { color: "#20372A", fontSize: 13, fontWeight: "800" }, toolGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 }, tool: { width: "48%", minHeight: 76, borderRadius: 15, borderWidth: 1, borderColor: "#E2E9E2", backgroundColor: "#FBFCFA", padding: 13, position: "relative" }, toolTitle: { color: "#20372A", fontSize: 14, fontWeight: "800" }, toolSubtitle: { color: "#718079", fontSize: 10, marginTop: 6 }, chevron: { position: "absolute", right: 12, top: 25, color: "#7E9587", fontSize: 22 }, statusCard: { marginHorizontal: 22, marginTop: 20, padding: 15, borderRadius: 15, backgroundColor: "#F3F8F3", flexDirection: "row", alignItems: "center" }, statusDot: { width: 10, height: 10, borderRadius: 6, backgroundColor: "#3E8E5B", marginRight: 11 }, statusTitle: { color: "#21463B", fontSize: 13, fontWeight: "800" }, statusText: { color: "#718079", fontSize: 11, marginTop: 3 }, statusArrow: { color: "#71907B", fontSize: 25 }, pressed: { opacity: 0.7, transform: [{ scale: 0.98 }] }, backdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.32)" }, sheet: { maxHeight: "82%", backgroundColor: "#FFFFFF", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 22 }, sheetHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }, sheetTitle: { color: "#17211D", fontSize: 22, fontWeight: "800" }, close: { color: "#1677FF", fontSize: 15, fontWeight: "700" }, panelRow: { flexDirection: "row", alignItems: "center", paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: "#EEF2EE" }, panelTitle: { color: "#20372A", fontSize: 15, fontWeight: "700" }, panelDetail: { color: "#718079", fontSize: 12, marginTop: 4 }, selected: { color: "#3E8E5B", fontSize: 23, marginLeft: 10 }, radio: { color: "#A9B5AC", fontSize: 23, marginLeft: 10 }, note: { color: "#718079", fontSize: 12, lineHeight: 18, marginTop: 16 }, fieldLabel: { color: "#68756D", fontSize: 10, fontWeight: "800", letterSpacing: 1.2, marginBottom: 8 }, inputLike: { borderWidth: 1, borderColor: "#DCE6DD", borderRadius: 12, padding: 14, marginBottom: 14, backgroundColor: "#FBFCFA" }, inputText: { color: "#20372A", fontSize: 15, fontWeight: "700" }, done: { marginTop: 18, backgroundColor: "#1677FF", paddingVertical: 14, borderRadius: 14, alignItems: "center" }, doneText: { color: "#FFFFFF", fontSize: 15, fontWeight: "800" } });
