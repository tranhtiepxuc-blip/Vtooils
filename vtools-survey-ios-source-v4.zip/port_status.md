# vTools Survey iOS — Ma trận port từ APK

## Đã hoạt động trong source iOS hiện tại

| Nhóm | Trạng thái | Ghi chú |
|---|---|---|
| Home dự án | Đã tích hợp | Bố cục dự án, trạng thái cục bộ, bản đồ nền và Thu thập nhanh theo ảnh APK. |
| Điểm/đường/vùng/tracklog | Đã tích hợp | Tạo và lưu cục bộ; bản native iOS dùng `react-native-maps` và GPS foreground. |
| Đo khoảng cách/diện tích | Đã tích hợp | Tính Haversine và diện tích xấp xỉ theo mặt phẳng cục bộ. |
| GeoJSON, GPX, KML cơ bản | Đã tích hợp | Parser cơ bản trong màn hình Map; file được chọn qua DocumentPicker. |
| Xuất GeoJSON | Đã tích hợp | Ghi file cục bộ và chia sẻ qua iOS share sheet. |
| Hệ tọa độ | Đã tích hợp một phần | Có lựa chọn WGS84, UTM tự động và VN-2000 trong UI, lưu lựa chọn cục bộ; chuyển đổi đầy đủ còn tiếp tục. |
| Tài nguyên giao diện APK | Đã tích hợp chọn lọc | Đã đưa nền OSM và compass vào assets iOS. |

## Đang tích hợp trong đợt port tổng thể

| Nhóm | Trạng thái | Việc còn lại |
|---|---|---|
| Lớp bản đồ | UI đã có | Nối lựa chọn OSM, satellite, WMS/TMS và MBTiles vào renderer iOS. |
| Nhập bản đồ nâng cao | UI và picker đã có | Parser SHP/DXF/MBTiles cần module native hoặc thư viện tương thích iOS. |
| Biểu mẫu/thuộc tính | UI khung đã có | Gắn schema thuộc tính vào từng GeoFeature và export CSV. |
| Offline | UI khung đã có | Cache tile, quản lý vùng tải và dung lượng. |
| GNSS/radar/la bàn | UI khung đã có | Dùng Location, Magnetometer và DeviceMotion trên iOS. |
| Ảnh/EXIF | UI khung đã có | Camera, metadata GPS và liên kết ảnh với đối tượng. |
| Project/restore/modify | UI khung đã có | Hoàn thiện schema project và khôi phục từ file. |

## Giới hạn kỹ thuật cần giữ nguyên trong bản iOS

APK Android không thể được chuyển nhị phân trực tiếp thành IPA. Các dịch vụ Android như foreground service, Mapbox/Carto native layer, GDAL và bộ đọc SHP/DXF phải được triển khai lại bằng API iOS hoặc module native tương thích. Những mục chưa có implementation native sẽ được ghi rõ trong giao diện và không được coi là đã hoàn tất chỉ vì có màn hình hiển thị.
