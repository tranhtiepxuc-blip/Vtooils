# Project TODO

- [x] Khởi tạo dự án Expo/React Native cho vTools Survey iOS
- [x] Viết thiết kế giao diện mobile theo iOS HIG trong design.md
- [x] Tạo logo ứng dụng và cập nhật cấu hình thương hiệu
- [x] Đặt mục tiêu triển khai iOS 17 và bundle identifier
- [x] Xây dựng màn hình Bản đồ với dữ liệu cục bộ
- [x] Hiển thị vị trí hiện tại và xin quyền vị trí
- [x] Tạo điểm, đường, vùng và tracklog
- [x] Lưu dự án và đối tượng khảo sát bằng AsyncStorage
- [ ] Bổ sung đo khoảng cách và diện tích
- [ ] Bổ sung nhập GPX, KML, GeoJSON và CSV
- [ ] Bổ sung xuất dữ liệu qua iOS share sheet
- [ ] Xây dựng màn hình Dự án, Chi tiết đối tượng và Cài đặt
- [ ] Thêm kiểm thử đơn vị cho logic hình học và lưu trữ
- [x] Thiết lập workflow GitHub Actions cho kiểm tra TypeScript, lint và build iOS
- [ ] Ghi rõ các secrets Apple/EAS cần thiết cho build ký mã
- [ ] Chạy kiểm thử và kiểm tra lỗi runtime
- [ ] Tạo checkpoint đầu tiên sau khi hoàn thiện MVP
- [x] Điều chỉnh workflow để tạo IPA không cần App Store distribution, phù hợp cài bằng TrollStore
- [x] Xuất IPA thành GitHub Actions artifact để tải xuống
- [x] Kiểm tra cấu trúc IPA và ghi hướng dẫn cài đặt bằng TrollStore
- [ ] Hướng dẫn tạo repository GitHub và đẩy mã nguồn dự án
- [ ] Hướng dẫn bật GitHub Actions và tải artifact IPA
- [ ] Thử tạo file IPA trực tiếp trong môi trường hiện tại và bàn giao nếu thành công
- [ ] Kiểm tra repository https://github.com/tranhtiepxuc1-creator/ipavtool và đối chiếu workflow tạo IPA
- [ ] Kiểm tra repository https://github.com/tranhtiepxuc-blip/Vtooils
- [ ] Thực hiện đẩy mã nguồn vào repository GitHub Vtooils theo ủy quyền của người dùng
- [ ] Xác nhận và giữ nguyên cấu hình IPA unsigned, không thêm certificate/provisioning/signing
- [ ] Sửa lỗi xcodebuild còn lại và chạy lại workflow unsigned

- [ ] Tiếp nhận APK hoặc mã nguồn dịch ngược do người dùng cung cấp để đối chiếu vTools Survey
- [ ] Lập bản đồ chức năng Android sang các màn hình và module iOS 17
- [ ] Sửa lỗi biên dịch native Expo/RN theo log xcodebuild mới nhất
- [ ] Chạy lại workflow và tạo IPA unsigned dùng cho TrollStore

- [x] Dùng ZIP decompile Android làm tài liệu chức năng thay cho việc chỉ dựa trên ZIP Expo cũ
- [x] Port các module ưu tiên từ Android sang bản iOS React Native/Expo
- [ ] Đóng gói lại ZIP nguồn iOS mới và cập nhật file trên GitHub
- [ ] Sửa workflow để biên dịch đúng ZIP nguồn iOS mới và tạo IPA unsigned

- [ ] Upload riêng ZIP decompile Android 65 MB lên GitHub với tên reference, không dùng làm input trực tiếp cho xcodebuild

- [x] Trích xuất layout, drawable, mipmap, assets và chuỗi giao diện từ ZIP decompile Android
- [x] Đối chiếu tài nguyên Android với màn hình iOS và thay các placeholder giao diện hiện tại
- [ ] Kiểm tra bản quyền/tính hợp lệ của tài nguyên trước khi đưa vào IPA
