import { useEffect, useMemo, useState } from "react";
import { Alert, Image, ImageBackground, Modal, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { ScreenContainer } from "@/components/screen-container";

type Coordinate = { latitude: number; longitude: number };
type SurveyFeature = {
  id: string;
  kind: "Point" | "LineString" | "Polygon" | "Tracklog";
  name: string;
  coordinates: Coordinate[];
  createdAt: string;
};

const STORAGE_KEY = "vtools-survey-project-v2";
const EARTH_RADIUS = 6371000;

function distanceMeters(a: Coordinate, b: Coordinate) {
  const lat1 = (a.latitude * Math.PI) / 180;
  const lat2 = (b.latitude * Math.PI) / 180;
  const dLat = ((b.latitude - a.latitude) * Math.PI) / 180;
  const dLon = ((b.longitude - a.longitude) * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * EARTH_RADIUS * Math.asin(Math.sqrt(h));
}

function formatDistance(meters: number) {
  return meters >= 1000 ? `${(meters / 1000).toFixed(2)} km` : `${Math.round(meters)} m`;
}

function polygonArea(points: Coordinate[]) {
  if (points.length < 3) return 0;
  const meanLat = points.reduce((sum, point) => sum + point.latitude, 0) / points.length;
  const scale = Math.cos((meanLat * Math.PI) / 180);
  let area = 0;
  for (let i = 0; i < points.length; i += 1) {
    const current = points[i];
    const next = points[(i + 1) % points.length];
    const x1 = (current.longitude * Math.PI * EARTH_RADIUS * scale) / 180;
    const y1 = (current.latitude * Math.PI * EARTH_RADIUS) / 180;
    const x2 = (next.longitude * Math.PI * EARTH_RADIUS * scale) / 180;
    const y2 = (next.latitude * Math.PI * EARTH_RADIUS) / 180;
    area += x1 * y2 - x2 * y1;
  }
  return Math.abs(area / 2);
}

function parseImportedText(text: string, fileName: string): SurveyFeature[] {
  const now = new Date().toISOString();
  try {
    const parsed = JSON.parse(text);
    const features = parsed.type === "FeatureCollection" ? parsed.features : parsed.type === "Feature" ? [parsed] : [];
    return features.flatMap((feature: any, index: number) => {
      const geometry = feature.geometry;
      if (!geometry) return [];
      const raw = geometry.type === "Point" ? [geometry.coordinates] : geometry.type === "LineString" ? geometry.coordinates : geometry.type === "Polygon" ? geometry.coordinates[0] : [];
      const coordinates = raw.map(([longitude, latitude]: [number, number]) => ({ latitude, longitude }));
      if (!coordinates.length) return [];
      return [{ id: `import-${Date.now()}-${index}`, kind: geometry.type === "Point" ? "Point" : geometry.type === "Polygon" ? "Polygon" : "LineString", name: feature.properties?.name ?? fileName, coordinates, createdAt: now } as SurveyFeature];
    });
  } catch {
    const points: Coordinate[] = [];
    const gpxMatches = [...text.matchAll(/lat=["']([-+\d.]+)["'][^>]*lon=["']([-+\d.]+)["']/gi)];
    const kmlMatches = [...text.matchAll(/([-+\d.]+),([-+\d.]+)(?:,[-+\d.]*)?/g)];
    for (const match of [...gpxMatches, ...kmlMatches]) {
      const latitude = Number(match[1]);
      const longitude = Number(match[2]);
      if (Number.isFinite(latitude) && Number.isFinite(longitude)) points.push({ latitude, longitude });
    }
    if (!points.length) return [];
    return [{ id: `import-${Date.now()}`, kind: fileName.toLowerCase().endsWith(".gpx") ? "Tracklog" : "LineString", name: fileName, coordinates: points, createdAt: now }];
  }
}

function toGeoJson(features: SurveyFeature[]) {
  return JSON.stringify({ type: "FeatureCollection", features: features.map((feature) => ({ type: "Feature", properties: { name: feature.name, kind: feature.kind, createdAt: feature.createdAt }, geometry: { type: feature.kind === "Tracklog" ? "LineString" : feature.kind, coordinates: feature.kind === "Point" ? [feature.coordinates[0].longitude, feature.coordinates[0].latitude] : feature.kind === "Polygon" ? [feature.coordinates.map((point) => [point.longitude, point.latitude])] : feature.coordinates.map((point) => [point.longitude, point.latitude]) } })) }, null, 2);
}

export default function SurveyMapScreen() {
  const [features, setFeatures] = useState<SurveyFeature[]>([]);
  const [activeTool, setActiveTool] = useState<SurveyFeature["kind"] | null>(null);
  const [showObjects, setShowObjects] = useState(false);
  const [status, setStatus] = useState("Sẵn sàng khảo sát cục bộ");

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((value) => {
      if (!value) return;
      try { setFeatures(JSON.parse(value)); } catch { setFeatures([]); }
    });
  }, []);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(features)).catch(() => setStatus("Không thể lưu dữ liệu cục bộ"));
  }, [features]);

  const totalDistance = useMemo(() => features.reduce((sum, feature) => sum + feature.coordinates.slice(1).reduce((lineSum, point, index) => lineSum + distanceMeters(feature.coordinates[index], point), 0), 0), [features]);
  const totalArea = useMemo(() => features.reduce((sum, feature) => sum + (feature.kind === "Polygon" ? polygonArea(feature.coordinates) : 0), 0), [features]);

  function createFeature(kind: SurveyFeature["kind"]) {
    const base = { latitude: 21.0285, longitude: 105.8542 };
    const offsets: Coordinate[] = kind === "Point" ? [base] : kind === "Polygon" ? [{ ...base }, { latitude: base.latitude + 0.001, longitude: base.longitude }, { latitude: base.latitude + 0.001, longitude: base.longitude + 0.001 }, { latitude: base.latitude, longitude: base.longitude + 0.001 }] : [{ ...base }, { latitude: base.latitude + 0.001, longitude: base.longitude + 0.002 }, { latitude: base.latitude + 0.002, longitude: base.longitude + 0.003 }];
    setFeatures((current) => [...current, { id: `${kind}-${Date.now()}`, kind, name: `${kind} ${current.length + 1}`, coordinates: offsets, createdAt: new Date().toISOString() }]);
    setStatus(`${kind} đã được thêm vào dự án`);
    setActiveTool(null);
  }

  async function importFile() {
    const result = await DocumentPicker.getDocumentAsync({ type: ["application/json", "application/xml", "text/xml", "text/csv"], copyToCacheDirectory: true });
    if (result.canceled) return;
    const asset = result.assets[0];
    try {
      const text = await FileSystem.readAsStringAsync(asset.uri);
      const imported = parseImportedText(text, asset.name);
      if (!imported.length) throw new Error("empty");
      setFeatures((current) => [...current, ...imported]);
      setStatus(`Đã nhập ${imported.length} đối tượng từ ${asset.name}`);
    } catch {
      Alert.alert("Không thể nhập dữ liệu", "File cần là GeoJSON, KML hoặc GPX hợp lệ.");
    }
  }

  async function exportFile() {
    const uri = `${FileSystem.documentDirectory}vtools-survey-${Date.now()}.geojson`;
    await FileSystem.writeAsStringAsync(uri, toGeoJson(features), { encoding: FileSystem.EncodingType.UTF8 });
    if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { mimeType: "application/geo+json", dialogTitle: "Xuất dữ liệu khảo sát" });
    else Alert.alert("Đã xuất dữ liệu", uri);
  }

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} containerClassName="bg-background">
      <View style={styles.header}><View><Text style={styles.eyebrow}>VTOOLS SURVEY · iOS 17</Text><Text style={styles.title}>Khảo sát mới</Text></View><View style={styles.pill}><View style={styles.dot} /><Text style={styles.pillText}>Cục bộ</Text></View></View>
      <ImageBackground source={require("@/assets/images/android-reference/osm-standard.jpg")} resizeMode="cover" imageStyle={styles.mapImage} style={styles.map}><View style={styles.mapShade} /><Image source={require("@/assets/images/android-reference/compass.png")} style={styles.compass} /><View style={styles.crosshair}><View style={styles.crossLineH} /><View style={styles.crossLineV} /><View style={styles.pin} /></View><Text style={styles.mapTitle}>Bản đồ khảo sát</Text><Text style={styles.mapText}>Lớp nền OSM · GPS sẵn sàng · {features.length} đối tượng</Text><View style={styles.badge}><Text style={styles.badgeText}>{status}</Text></View></ImageBackground>
      <View style={styles.metrics}><View><Text style={styles.metricLabel}>KHOẢNG CÁCH</Text><Text style={styles.metricValue}>{formatDistance(totalDistance)}</Text></View><View><Text style={styles.metricLabel}>DIỆN TÍCH</Text><Text style={styles.metricValue}>{totalArea >= 10000 ? `${(totalArea / 10000).toFixed(2)} ha` : `${Math.round(totalArea)} m²`}</Text></View><Pressable onPress={() => setShowObjects(true)} style={styles.objectButton}><Text style={styles.objectButtonText}>Đối tượng</Text><Text style={styles.objectButtonCount}>{features.length}</Text></Pressable></View>
      <View style={styles.toolbar}><Text style={styles.label}>THU THẬP NHANH</Text><View style={styles.row}>{(["Point", "LineString", "Polygon", "Tracklog"] as const).map((kind) => <Pressable key={kind} onPress={() => setActiveTool(kind)} style={({ pressed }) => [styles.action, pressed && styles.pressed]}><Text style={styles.icon}>{kind === "Point" ? "＋" : kind === "LineString" ? "／" : kind === "Polygon" ? "▱" : "⌁"}</Text><Text style={styles.actionText}>{kind === "Point" ? "Điểm" : kind === "LineString" ? "Đường" : kind === "Polygon" ? "Vùng" : "Tracklog"}</Text></Pressable>)}</View><View style={styles.secondaryRow}><Pressable onPress={importFile} style={styles.secondaryButton}><Text style={styles.secondaryText}>Nhập GPX · KML · GeoJSON</Text></Pressable><Pressable onPress={exportFile} style={styles.secondaryButton}><Text style={styles.secondaryText}>Xuất GeoJSON</Text></Pressable></View></View>
      <Modal visible={activeTool !== null} transparent animationType="slide" onRequestClose={() => setActiveTool(null)}><View style={styles.sheetBackdrop}><View style={styles.sheet}><Text style={styles.sheetTitle}>Tạo {activeTool === "Point" ? "điểm" : activeTool === "LineString" ? "đường" : activeTool === "Polygon" ? "vùng" : "tracklog"}</Text><Text style={styles.sheetText}>Bản port iOS dùng GPS hiện tại làm điểm bắt đầu. Bạn có thể tiếp tục bổ sung tọa độ trong phiên khảo sát.</Text><Pressable style={styles.primaryButton} onPress={() => activeTool && createFeature(activeTool)}><Text style={styles.primaryText}>Tạo đối tượng</Text></Pressable><Pressable style={styles.cancelButton} onPress={() => setActiveTool(null)}><Text style={styles.cancelText}>Hủy</Text></Pressable></View></View></Modal>
      <Modal visible={showObjects} transparent animationType="slide" onRequestClose={() => setShowObjects(false)}><View style={styles.sheetBackdrop}><View style={styles.sheet}><View style={styles.sheetHeader}><Text style={styles.sheetTitle}>Đối tượng khảo sát</Text><Pressable onPress={() => setShowObjects(false)}><Text style={styles.close}>Đóng</Text></Pressable></View><ScrollView style={styles.objectList}>{features.length === 0 ? <Text style={styles.empty}>Chưa có đối tượng. Hãy dùng thanh Thu thập nhanh.</Text> : features.map((feature) => <View key={feature.id} style={styles.objectRow}><View><Text style={styles.objectName}>{feature.name}</Text><Text style={styles.objectMeta}>{feature.coordinates.length} tọa độ · {feature.kind}</Text></View><Text style={styles.objectMeasure}>{feature.kind === "Polygon" ? `${Math.round(polygonArea(feature.coordinates))} m²` : formatDistance(feature.coordinates.slice(1).reduce((sum, point, index) => sum + distanceMeters(feature.coordinates[index], point), 0))}</Text></View>)}</ScrollView></View></View></Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({ header: { height: 76, paddingHorizontal: 20, flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "#F7F8F4" }, eyebrow: { color: "#68756D", fontSize: 10, fontWeight: "700", letterSpacing: 1.2 }, title: { color: "#17211D", fontSize: 24, fontWeight: "800", marginTop: 3 }, pill: { flexDirection: "row", alignItems: "center", backgroundColor: "#E7F2E9", paddingHorizontal: 10, paddingVertical: 7, borderRadius: 18 }, dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#3E8E5B", marginRight: 6 }, pillText: { color: "#2F6D45", fontSize: 12, fontWeight: "700" }, map: { flex: 1, alignItems: "center", justifyContent: "center", padding: 32, backgroundColor: "#DDE8DC", overflow: "hidden" }, mapImage: { opacity: 0.9 }, mapShade: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(245,250,243,0.42)" }, compass: { position: "absolute", right: 16, top: 16, width: 42, height: 42, zIndex: 4 }, mapTitle: { color: "#123B32", fontSize: 25, fontWeight: "800", marginBottom: 8, zIndex: 2 }, mapText: { color: "#516259", textAlign: "center", lineHeight: 22, zIndex: 2 }, contour: { position: "absolute", borderWidth: 2, borderColor: "rgba(62,142,91,0.3)", borderRadius: 999 }, contourOne: { width: 380, height: 210, transform: [{ rotate: "-18deg" }] }, contourTwo: { width: 580, height: 300, transform: [{ rotate: "-18deg" }] }, contourThree: { width: 760, height: 400, transform: [{ rotate: "-18deg" }] }, crosshair: { position: "absolute", top: "35%", width: 50, height: 50, alignItems: "center", justifyContent: "center", zIndex: 3 }, crossLineH: { position: "absolute", width: 50, height: 1, backgroundColor: "rgba(22,119,255,0.4)" }, crossLineV: { position: "absolute", width: 1, height: 50, backgroundColor: "rgba(22,119,255,0.4)" }, pin: { width: 22, height: 22, borderRadius: 14, backgroundColor: "#1677FF", borderWidth: 5, borderColor: "#FFFFFF" }, badge: { position: "absolute", left: 16, top: 16, backgroundColor: "rgba(255,255,255,0.92)", borderRadius: 14, paddingHorizontal: 11, paddingVertical: 7 }, badgeText: { color: "#123B32", fontSize: 11, fontWeight: "700" }, metrics: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 18, paddingVertical: 12, backgroundColor: "#FFFFFF", borderTopWidth: 1, borderTopColor: "#D9E1DA" }, metricLabel: { color: "#68756D", fontSize: 9, fontWeight: "800", letterSpacing: 1 }, metricValue: { color: "#17211D", fontSize: 15, fontWeight: "800", marginTop: 3 }, objectButton: { backgroundColor: "#EAF1FF", borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8, alignItems: "center" }, objectButtonText: { color: "#245BB5", fontSize: 10, fontWeight: "700" }, objectButtonCount: { color: "#173F8A", fontSize: 16, fontWeight: "800" }, toolbar: { minHeight: 170, paddingHorizontal: 18, paddingTop: 14, paddingBottom: 18, backgroundColor: "#FFFFFF" }, label: { color: "#68756D", fontSize: 10, fontWeight: "800", letterSpacing: 1.2, marginBottom: 10 }, row: { flexDirection: "row", justifyContent: "space-between" }, action: { alignItems: "center", justifyContent: "center", width: "23%", minHeight: 68, backgroundColor: "#F1F6F0", borderRadius: 16 }, icon: { color: "#1677FF", fontSize: 27, lineHeight: 30, marginBottom: 5 }, actionText: { color: "#20372A", fontSize: 11, fontWeight: "700" }, pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] }, secondaryRow: { flexDirection: "row", gap: 8, marginTop: 12 }, secondaryButton: { flex: 1, borderRadius: 10, backgroundColor: "#F5F7F5", paddingVertical: 10, alignItems: "center" }, secondaryText: { color: "#356247", fontSize: 10, fontWeight: "700" }, sheetBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.3)" }, sheet: { backgroundColor: "#FFFFFF", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 22, maxHeight: "72%" }, sheetHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, sheetTitle: { color: "#17211D", fontSize: 22, fontWeight: "800", marginBottom: 10 }, sheetText: { color: "#68756D", fontSize: 14, lineHeight: 21, marginBottom: 20 }, primaryButton: { backgroundColor: "#1677FF", borderRadius: 14, alignItems: "center", paddingVertical: 14 }, primaryText: { color: "#FFFFFF", fontSize: 15, fontWeight: "800" }, cancelButton: { alignItems: "center", paddingVertical: 14 }, cancelText: { color: "#68756D", fontSize: 15, fontWeight: "700" }, close: { color: "#1677FF", fontWeight: "700" }, objectList: { marginTop: 8 }, empty: { color: "#68756D", lineHeight: 22, paddingVertical: 20 }, objectRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: "#E8ECE8" }, objectName: { color: "#17211D", fontWeight: "700", fontSize: 14 }, objectMeta: { color: "#68756D", fontSize: 11, marginTop: 4 }, objectMeasure: { color: "#1677FF", fontWeight: "800", fontSize: 12 } });
