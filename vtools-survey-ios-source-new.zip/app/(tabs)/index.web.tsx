import { useEffect, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ScreenContainer } from "@/components/screen-container";

const STORAGE_KEY = "vtools-survey-project-v1";

export default function WebHomeScreen() {
  const [count, setCount] = useState(0);
  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((value) => setCount(value ? JSON.parse(value).length : 0));
  }, []);
  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} containerClassName="bg-background">
      <View style={styles.header}><View><Text style={styles.eyebrow}>DỰ ÁN HIỆN TẠI</Text><Text style={styles.title}>Khảo sát mới</Text></View><View style={styles.pill}><View style={styles.dot} /><Text style={styles.pillText}>Cục bộ</Text></View></View>
      <View style={styles.map}><View style={[styles.contour, styles.contourOne]} /><View style={[styles.contour, styles.contourTwo]} /><View style={[styles.contour, styles.contourThree]} /><View style={styles.pin}><View style={styles.pinCenter} /></View><Text style={styles.mapTitle}>Bản đồ khảo sát</Text><Text style={styles.mapText}>Mở ứng dụng trên iPhone để sử dụng bản đồ GPS tương tác.</Text><View style={styles.badge}><Text style={styles.badgeText}>{count} đối tượng</Text></View></View>
      <View style={styles.toolbar}><Text style={styles.label}>THU THẬP NHANH</Text><View style={styles.row}>{["Điểm", "Đường", "Vùng", "Tracklog"].map((item) => <Pressable key={item} style={({ pressed }) => [styles.action, pressed && styles.pressed]}><Text style={styles.icon}>{item === "Điểm" ? "＋" : item === "Đường" ? "／" : item === "Vùng" ? "▱" : "⌁"}</Text><Text style={styles.actionText}>{item}</Text></Pressable>)}</View></View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({ header: { height: 76, paddingHorizontal: 20, flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "#F7F8F4" }, eyebrow: { color: "#68756D", fontSize: 10, fontWeight: "700", letterSpacing: 1.2 }, title: { color: "#17211D", fontSize: 24, fontWeight: "800", marginTop: 3 }, pill: { flexDirection: "row", alignItems: "center", backgroundColor: "#E7F2E9", paddingHorizontal: 10, paddingVertical: 7, borderRadius: 18 }, dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#3E8E5B", marginRight: 6 }, pillText: { color: "#2F6D45", fontSize: 12, fontWeight: "700" }, map: { flex: 1, alignItems: "center", justifyContent: "center", padding: 32, backgroundColor: "#DDE8DC", overflow: "hidden" }, mapTitle: { color: "#123B32", fontSize: 25, fontWeight: "800", marginBottom: 8, zIndex: 2 }, mapText: { color: "#516259", textAlign: "center", lineHeight: 22, zIndex: 2 }, contour: { position: "absolute", borderWidth: 2, borderColor: "rgba(62,142,91,0.3)", borderRadius: 999 }, contourOne: { width: 380, height: 210, transform: [{ rotate: "-18deg" }] }, contourTwo: { width: 580, height: 300, transform: [{ rotate: "-18deg" }] }, contourThree: { width: 760, height: 400, transform: [{ rotate: "-18deg" }] }, pin: { position: "absolute", top: "35%", width: 36, height: 36, borderRadius: 22, backgroundColor: "#1677FF", alignItems: "center", justifyContent: "center", zIndex: 3 }, pinCenter: { width: 12, height: 12, borderRadius: 8, backgroundColor: "#FFFFFF" }, badge: { position: "absolute", left: 16, top: 16, backgroundColor: "rgba(255,255,255,0.92)", borderRadius: 14, paddingHorizontal: 11, paddingVertical: 7 }, badgeText: { color: "#123B32", fontSize: 12, fontWeight: "700" }, toolbar: { minHeight: 138, paddingHorizontal: 18, paddingTop: 14, paddingBottom: 18, backgroundColor: "#FFFFFF", borderTopWidth: 1, borderTopColor: "#D9E1DA" }, label: { color: "#68756D", fontSize: 10, fontWeight: "800", letterSpacing: 1.2, marginBottom: 10 }, row: { flexDirection: "row", justifyContent: "space-between" }, action: { alignItems: "center", justifyContent: "center", width: "23%", minHeight: 76, backgroundColor: "#F1F6F0", borderRadius: 16 }, icon: { color: "#1677FF", fontSize: 27, lineHeight: 30, marginBottom: 5 }, actionText: { color: "#20372A", fontSize: 11, fontWeight: "700" }, pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] } });
