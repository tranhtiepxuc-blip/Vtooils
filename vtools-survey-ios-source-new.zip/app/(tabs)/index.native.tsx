import { useEffect, useMemo, useRef, useState } from "react";
import { Alert, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import MapView, { Marker, Polygon, Polyline, Region } from "react-native-maps";
import * as Location from "expo-location";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ScreenContainer } from "@/components/screen-container";

 type SurveyMode = "point" | "line" | "polygon" | "track" | null;
 type Coordinate = { latitude: number; longitude: number };
 type SurveyObject = { id: string; type: Exclude<SurveyMode, null>; name: string; coordinates: Coordinate[] };

const STORAGE_KEY = "vtools-survey-project-v1";
const DEFAULT_REGION: Region = { latitude: 16.0471, longitude: 108.2068, latitudeDelta: 7.2, longitudeDelta: 7.2 };

export default function HomeScreen() {
  const mapRef = useRef<MapView>(null);
  const [region, setRegion] = useState<Region>(DEFAULT_REGION);
  const [currentLocation, setCurrentLocation] = useState<Coordinate | null>(null);
  const [objects, setObjects] = useState<SurveyObject[]>([]);
  const [mode, setMode] = useState<SurveyMode>(null);
  const [draft, setDraft] = useState<Coordinate[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((value) => {
      if (value) setObjects(JSON.parse(value) as SurveyObject[]);
      setIsLoaded(true);
    });
  }, []);

  useEffect(() => {
    if (isLoaded) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(objects));
  }, [objects, isLoaded]);

  useEffect(() => {
    let subscription: Location.LocationSubscription | undefined;
    (async () => {
      if (Platform.OS === "web") return;
      const services = await Location.hasServicesEnabledAsync();
      if (!services) return;
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== "granted") return;
      const first = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coordinate = { latitude: first.coords.latitude, longitude: first.coords.longitude };
      setCurrentLocation(coordinate);
      setRegion({ ...coordinate, latitudeDelta: 0.015, longitudeDelta: 0.015 });
      subscription = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.Balanced, distanceInterval: 8, timeInterval: 5000 },
        (next) => setCurrentLocation({ latitude: next.coords.latitude, longitude: next.coords.longitude }),
      );
    })();
    return () => subscription?.remove();
  }, []);

  const lineObjects = useMemo(() => objects.filter((item) => item.type === "line" || item.type === "track"), [objects]);
  const polygonObjects = useMemo(() => objects.filter((item) => item.type === "polygon"), [objects]);

  const selectMode = (nextMode: Exclude<SurveyMode, null>) => {
    setMode(nextMode);
    setDraft([]);
  };

  const handleMapPress = (event: { nativeEvent: { coordinate: Coordinate } }) => {
    if (!mode) return;
    const coordinate = event.nativeEvent.coordinate;
    if (mode === "point") {
      setObjects((items) => [...items, { id: `${Date.now()}`, type: mode, name: `Điểm ${items.length + 1}`, coordinates: [coordinate] }]);
      setMode(null);
      return;
    }
    setDraft((items) => [...items, coordinate]);
  };

  const finishDraft = () => {
    if (!mode || draft.length < (mode === "line" || mode === "track" ? 2 : 3)) {
      Alert.alert("Chưa đủ dữ liệu", "Đường cần ít nhất 2 điểm, vùng cần ít nhất 3 điểm.");
      return;
    }
    setObjects((items) => [...items, { id: `${Date.now()}`, type: mode, name: `${mode === "track" ? "Tracklog" : mode === "line" ? "Đường" : "Vùng"} ${items.length + 1}`, coordinates: draft }]);
    setDraft([]);
    setMode(null);
  };

  const centerOnUser = () => {
    if (!currentLocation) {
      Alert.alert("Chưa có vị trí", "Hãy cho phép truy cập vị trí để định tâm bản đồ.");
      return;
    }
    mapRef.current?.animateToRegion({ ...currentLocation, latitudeDelta: 0.015, longitudeDelta: 0.015 }, 450);
  };

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} containerClassName="bg-background">
      <View style={styles.header}>
        <View>
          <Text style={styles.eyebrow}>DỰ ÁN HIỆN TẠI</Text>
          <Text style={styles.title}>Khảo sát mới</Text>
        </View>
        <View style={styles.statusPill}><View style={styles.statusDot} /><Text style={styles.statusText}>Cục bộ</Text></View>
      </View>
      <View style={styles.mapWrap}>
        {Platform.OS === "web" ? (
          <View style={styles.webMapFallback}><Text style={styles.webMapTitle}>Bản đồ khảo sát</Text><Text style={styles.webMapText}>Mở ứng dụng trên iPhone để sử dụng bản đồ GPS tương tác.</Text></View>
        ) : (
          <MapView ref={mapRef} style={StyleSheet.absoluteFill} initialRegion={region} region={region} onRegionChangeComplete={setRegion} onPress={handleMapPress} showsUserLocation={Boolean(currentLocation)} showsMyLocationButton={false} mapType="standard">
            {objects.filter((item) => item.type === "point").map((item) => <Marker key={item.id} coordinate={item.coordinates[0]} title={item.name} pinColor="#1677FF" />)}
            {lineObjects.map((item) => <Polyline key={item.id} coordinates={item.coordinates} strokeColor={item.type === "track" ? "#D97706" : "#3E8E5B"} strokeWidth={4} />)}
            {polygonObjects.map((item) => <Polygon key={item.id} coordinates={item.coordinates} strokeColor="#3E8E5B" fillColor="rgba(62,142,91,0.22)" strokeWidth={3} />)}
            {draft.length > 0 && (mode === "polygon" ? <Polygon coordinates={draft} strokeColor="#1677FF" fillColor="rgba(22,119,255,0.16)" strokeWidth={3} /> : <Polyline coordinates={draft} strokeColor="#1677FF" strokeWidth={4} />)}
          </MapView>
        )}
        <Pressable onPress={centerOnUser} style={({ pressed }) => [styles.floatingButton, pressed && styles.pressed]}><Text style={styles.floatingIcon}>⌖</Text></Pressable>
        <View style={styles.mapBadge}><Text style={styles.mapBadgeText}>{objects.length} đối tượng</Text></View>
      </View>
      <View style={styles.toolbar}>
        {mode ? <View style={styles.activeMode}><Text style={styles.activeModeText}>Đang tạo {mode === "point" ? "điểm" : mode === "line" ? "đường" : mode === "polygon" ? "vùng" : "tracklog"} · {draft.length} điểm</Text><Pressable onPress={finishDraft} style={styles.finishButton}><Text style={styles.finishText}>Lưu</Text></Pressable></View> : <>
          <Text style={styles.sectionLabel}>THU THẬP NHANH</Text>
          <View style={styles.actionRow}>
            <ActionButton label="Điểm" icon="＋" onPress={() => selectMode("point")} />
            <ActionButton label="Đường" icon="／" onPress={() => selectMode("line")} />
            <ActionButton label="Vùng" icon="▱" onPress={() => selectMode("polygon")} />
            <ActionButton label="Tracklog" icon="⌁" onPress={() => selectMode("track")} />
          </View>
        </>}
      </View>
    </ScreenContainer>
  );
}

function ActionButton({ label, icon, onPress }: { label: string; icon: string; onPress: () => void }) {
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.actionButton, pressed && styles.pressed]}><Text style={styles.actionIcon}>{icon}</Text><Text style={styles.actionLabel}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({
  header: { height: 76, paddingHorizontal: 20, flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "#F7F8F4" },
  eyebrow: { color: "#68756D", fontSize: 10, fontWeight: "700", letterSpacing: 1.2 },
  title: { color: "#17211D", fontSize: 24, fontWeight: "800", marginTop: 3 },
  statusPill: { flexDirection: "row", alignItems: "center", backgroundColor: "#E7F2E9", paddingHorizontal: 10, paddingVertical: 7, borderRadius: 18 },
  statusDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#3E8E5B", marginRight: 6 },
  statusText: { color: "#2F6D45", fontSize: 12, fontWeight: "700" },
  mapWrap: { flex: 1, overflow: "hidden", backgroundColor: "#DDE8DC", position: "relative" },
  webMapFallback: { flex: 1, alignItems: "center", justifyContent: "center", padding: 32, backgroundColor: "#DDE8DC" },
  webMapTitle: { color: "#123B32", fontSize: 25, fontWeight: "800", marginBottom: 8 },
  webMapText: { color: "#516259", textAlign: "center", lineHeight: 22 },
  floatingButton: { position: "absolute", right: 16, bottom: 18, width: 48, height: 48, borderRadius: 24, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center", shadowColor: "#123B32", shadowOpacity: 0.18, shadowRadius: 8, elevation: 3 },
  floatingIcon: { color: "#1677FF", fontSize: 28 },
  mapBadge: { position: "absolute", left: 16, top: 16, backgroundColor: "rgba(255,255,255,0.92)", borderRadius: 14, paddingHorizontal: 11, paddingVertical: 7 },
  mapBadgeText: { color: "#123B32", fontSize: 12, fontWeight: "700" },
  toolbar: { minHeight: 138, paddingHorizontal: 18, paddingTop: 14, paddingBottom: 18, backgroundColor: "#FFFFFF", borderTopWidth: 1, borderTopColor: "#D9E1DA" },
  sectionLabel: { color: "#68756D", fontSize: 10, fontWeight: "800", letterSpacing: 1.2, marginBottom: 10 },
  actionRow: { flexDirection: "row", justifyContent: "space-between" },
  actionButton: { alignItems: "center", justifyContent: "center", width: "23%", minHeight: 76, backgroundColor: "#F1F6F0", borderRadius: 16 },
  actionIcon: { color: "#1677FF", fontSize: 27, lineHeight: 30, marginBottom: 5 },
  actionLabel: { color: "#20372A", fontSize: 11, fontWeight: "700" },
  activeMode: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "#EAF2FF", borderRadius: 15, padding: 14 },
  activeModeText: { flex: 1, color: "#24528D", fontWeight: "700", fontSize: 13 },
  finishButton: { paddingHorizontal: 17, paddingVertical: 9, backgroundColor: "#1677FF", borderRadius: 18 },
  finishText: { color: "#FFFFFF", fontWeight: "800" },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
});
