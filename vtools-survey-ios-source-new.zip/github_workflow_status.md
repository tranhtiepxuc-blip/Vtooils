Repository: https://github.com/tranhtiepxuc-blip/Vtooils
Workflow path: https://github.com/tranhtiepxuc-blip/Vtooils/blob/main/.github/workflows/ios.yml
Commit 86fa036 created an empty 1-byte workflow and failed with “No event triggers defined in on”. I edited the file through GitHub web UI and committed corrected content in commit 4e5779b. The current GitHub page reports 160 lines / 2.56 KB and displays valid-looking triggers: workflow_dispatch and push tags v*. Workflow extracts vtools-survey-ios-source.zip into source, installs pnpm dependencies, runs pnpm check, Expo prebuild, CocoaPods, xcodebuild unsigned Release, packages Payload as source/build/vtools-survey-ios.ipa, and uploads artifact. Next action is rerun workflow from Actions and inspect build logs.
Run 31756652808 failed after 56 seconds in Expo prebuild while CocoaPods evaluated Podfile. Exact error: React Native requires Xcode >= 16.1, but runner macos-14 provided Xcode 15.4; Podfile says “Please upgrade XCode.” Fix: change runs-on from macos-14 to macos-15 (Xcode 16.x).

6. Run 31756926686 (#3) dùng macos-15 nhưng thất bại ở bước Build unsigned Release app sau 8m57s. Lỗi chính: thiếu ExpoModulesCore.modulemap khi biên dịch ExpoSystemUIModule.swift, xcodebuild exit code 65.
7. Đã commit bản sửa workflow tại commit 4292057: clean build, pod install --repo-update, CI=1, destination generic/platform=iOS, -parallelizeTargets NO và -jobs 1.
8. Run 31758041537 (#4) trên commit 4292057 đang In progress; job build-ipa id 94638079845; chưa có artifact tại thời điểm ghi chú.

10. Run 31758344271 (#5) trên commit 92de7dc thất bại sau 1m40s ở bước Build unsigned Release app. Workspace đã nhận đúng, nhưng xcodebuild báo `Unknown build action 'NO'` vì `-parallelizeTargets NO` không hợp lệ; cần bỏ tham số này và thay bằng build setting giới hạn concurrency nếu cần.

11. Run 31758671755 (#6) đã vượt qua install dependencies, validate, Expo prebuild, CocoaPods và đang ở bước Build unsigned Release app; chưa có artifact tại thời điểm kiểm tra. Run #5 xác nhận lỗi trực tiếp là `Unknown build action 'NO'`; commit 41a2d8c đã bỏ cờ này, cần chờ kết quả run #6.

12. Người dùng xác nhận chỉ cần IPA unsigned để cài bằng TrollStore. Workflow hiện giữ CODE_SIGNING_ALLOWED=NO, CODE_SIGNING_REQUIRED=NO và không dùng certificate/provisioning. Run #6 chưa có artifact; xcodebuild dừng sau khoảng 20 phút ở bước build, cần tiếp tục chẩn đoán lỗi native/compiler.
