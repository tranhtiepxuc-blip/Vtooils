# Thiết kế giao diện vTools Survey cho iOS 17

## Định hướng sản phẩm

vTools Survey iOS là công cụ khảo sát thực địa ưu tiên thao tác một tay, hoạt động được khi mất kết nối và trình bày dữ liệu không gian theo cách rõ ràng như một ứng dụng iOS bản địa. MVP tập trung vào bản đồ, vị trí hiện tại, tạo đối tượng khảo sát, tracklog, đo nhanh và quản lý dự án cục bộ. Dữ liệu mặc định được lưu trên thiết bị; chưa đưa tài khoản hoặc đồng bộ đám mây vào MVP.

## Danh sách màn hình

| Màn hình | Nội dung chính | Chức năng |
|---|---|---|
| Bản đồ | Bản đồ nền, vị trí hiện tại, lớp dữ liệu, điểm/đường/vùng đã tạo | Di chuyển bản đồ, định tâm GPS, chọn đối tượng, bật/tắt lớp |
| Thu thập | Thanh công cụ tạo điểm, đường, vùng và tracklog | Bắt đầu/tạm dừng/kết thúc thu thập; nhập thuộc tính nhanh |
| Dự án | Danh sách dự án khảo sát cục bộ | Tạo, đổi tên, mở, sao chép và xóa dự án |
| Chi tiết đối tượng | Hình học, tọa độ, diện tích/khoảng cách và thuộc tính | Chỉnh sửa thuộc tính, thêm ảnh, xóa hoặc chia sẻ |
| Nhập/Xuất | Các định dạng GPX, KML, GeoJSON, CSV | Chọn tệp, xem trước, nhập vào dự án, xuất qua share sheet |
| Cài đặt | Đơn vị đo, hệ tọa độ, bản đồ nền, quyền vị trí, giao diện | Điều chỉnh cấu hình và xem thông tin ứng dụng |

## Bố cục và thao tác một tay

Màn hình Bản đồ chiếm toàn bộ vùng nội dung. Các nút nổi quan trọng nằm ở vùng dưới bên phải nhưng không che thanh tab: định tâm vị trí, lớp bản đồ và nút hành động chính. Khi người dùng nhấn nút hành động, một bottom sheet iOS hiển thị bốn lựa chọn Điểm, Đường, Vùng và Tracklog. Các thao tác kết thúc hoặc lưu được đặt trong vùng dễ chạm ở cạnh dưới.

Thanh tab gồm **Bản đồ**, **Thu thập**, **Dự án** và **Cài đặt**. Màn hình Chi tiết đối tượng, Nhập/Xuất và biểu mẫu thuộc tính mở bằng stack navigation hoặc sheet, với nút quay lại và tiêu đề ngắn gọn theo chuẩn iOS.

## Luồng người dùng chính

### Tạo điểm khảo sát

Người dùng mở một dự án → vào Bản đồ → nhấn nút hành động → chọn Điểm → chạm trên bản đồ hoặc dùng vị trí hiện tại → nhập tên và thuộc tính → lưu. Sau khi lưu, điểm xuất hiện trên bản đồ và trong danh sách đối tượng của dự án.

### Ghi tracklog

Người dùng vào Thu thập → chọn Tracklog → cấp quyền vị trí khi được hỏi → nhấn Bắt đầu → theo dõi thời gian, quãng đường và độ chính xác GPS → nhấn Tạm dừng hoặc Kết thúc → đặt tên → lưu tracklog vào dự án.

### Nhập và xuất dữ liệu

Người dùng mở Dự án → chọn Nhập/Xuất → chọn định dạng → mở Files của iOS để chọn GPX, KML, GeoJSON hoặc CSV → xem trước số lượng đối tượng → xác nhận nhập. Khi xuất, người dùng chọn lớp hoặc toàn bộ dự án → chọn định dạng → mở share sheet của iOS.

## Ngôn ngữ hình ảnh và màu sắc

Màu thương hiệu lấy cảm hứng từ bản đồ địa hình và tín hiệu GPS: xanh rừng đậm `#123B32` cho tiêu đề và vùng điều hướng, xanh định vị `#1677FF` cho hành động chính, xanh địa hình `#3E8E5B` cho dữ liệu đã lưu, nền giấy bản đồ `#F7F8F4`, bề mặt `#FFFFFF`, chữ chính `#17211D`, chữ phụ `#68756D`, đường viền `#D9E1DA`, cảnh báo `#B7791F` và lỗi `#C53D3D`. Chế độ tối sẽ dùng nền `#101612`, bề mặt `#18221B`, chữ `#F1F6F0` và giữ xanh định vị ở mức tương phản cao.

Các đối tượng trên bản đồ dùng quy ước nhất quán: điểm là chấm tròn xanh dương, đường là nét xanh lá, vùng là tô xanh lá trong suốt, tracklog là nét cam. Không dùng màu chỉ để truyền đạt trạng thái; mọi trạng thái quan trọng đều có nhãn hoặc biểu tượng.

## Quy tắc iOS 17

Giao diện dùng typography hệ thống, vùng an toàn, bottom sheet, swipe-back, haptic nhẹ cho hành động chính và trạng thái nhấn trực quan. Nút chạm tối thiểu khoảng 44 điểm, văn bản không bị cắt khi Dynamic Type tăng cỡ, và các thao tác nguy hiểm như xóa dự án luôn yêu cầu xác nhận. Ứng dụng yêu cầu quyền vị trí với giải thích cụ thể trong Info.plist và cho phép tiếp tục ở chế độ xem dữ liệu nếu người dùng từ chối quyền.
