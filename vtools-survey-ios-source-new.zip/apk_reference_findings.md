# APK reference findings

## Source package

- Version: 6.9.2, versionCode 292
- Package: `com.xyz.survey`
- Main application class: `com.vn.geotech.vtools.Apps`
- Decompiled source root: `/home/ubuntu/apk_reference/vTools_Survey_6.9.2_Th3-R3p4ck3r.apk_Decompiler.com`

## Android permissions and capabilities

- Fine/coarse location and background location.
- Foreground location services for tracklog, polygon and polyline capture.
- Camera, microphone feature declaration, notifications, internet/network access.
- External storage access on older Android versions and file provider for import/export.

## Activities identified

- Splash and intro: `Activity_Splash`, `Activity_Intro`
- Main map/workspace: `Activity_Main`
- Options/about/access/copyright/preferences: `Activity_Options`, `Activity_About`, `Activity_Access`, `Activity_Copyright`, `Activity_Preference`
- Forms and data entry: `Activity_Forms`, `Activity_Input`, `Activity_Attribute`
- Media and sensors: `Activity_Photo`, `Activity_Camera`, `Activity_Exif`, `Activity_Compass`, `Activity_Sphere`, `Activity_Bubble`, `Activity_Terrain`
- Geometry and measurement: `Activity_Geometry`, `Activity_Ruler`
- File and project workflows: `Activity_Picker`, `Activity_Import`, `Activity_Export`, `Activity_Offline`, `Activity_Project`, `Activity_Modify`, `Activity_Restore`
- Survey/projection/earth/firms/manual: `Activity_Survey`, `Activity_Projection`, `Activity_Earth`, `Activity_Firms`, `Activity_Manual`

## Background services

- `Service_Tracklog` for location foreground service.
- `Service_Polygon` for polygon capture.
- `Service_Polyline` for polyline capture.
- `Service_Access` for connected-device access.

## Porting implication

The current iOS MVP covers the map, GPS, point/line/polygon/tracklog and local persistence. The APK confirms the next high-value port areas are project management, forms/attributes, geometry/ruler measurement, import/export/offline workflows, media capture/EXIF, compass/slope/terrain tools, and background location tracking. Android APK bytecode cannot be converted directly into an iOS IPA; these capabilities must be reimplemented against iOS APIs and Expo modules.
